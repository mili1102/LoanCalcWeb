document.getElementById("calcButton").addEventListener("click", function() {
    let principal = parseFloat(document.getElementById("principal").value);
    let rate = parseFloat(document.getElementById("rate").value);
    let years = parseFloat(document.getElementById("years").value);
    let currency = document.getElementById("currency").value;
  
    if (isNaN(principal) || isNaN(rate) || isNaN(years)) {
      document.getElementById("result").innerText = "Please enter valid numbers.";
      return;
    }
  
    let monthlyRate = rate / 100 / 12;
    let payments = years * 12;
    let x = Math.pow(1 + monthlyRate, payments);
    let monthlyPayment = (principal * monthlyRate * x) / (x - 1);
  
    document.getElementById("result").innerText = 
      `Monthly Payment: ${currency}${monthlyPayment.toFixed(2)}`;
  });